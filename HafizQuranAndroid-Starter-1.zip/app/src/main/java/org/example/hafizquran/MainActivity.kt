package org.example.hafizquran

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray

class MainActivity : Activity() {
    private val green = Color.rgb(10, 78, 55)
    private val gold = Color.rgb(211, 170, 75)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(250, 248, 240))
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = "حافظ القرآن الكريم"
            textSize = 26f
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            gravity = Gravity.CENTER
            setPadding(16, 28, 16, 28)
            typeface = Typeface.DEFAULT_BOLD
        }
        outer.addView(header)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }
        val status = TextView(this).apply {
            textSize = 18f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(status)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        try {
            val raw = assets.open("quran.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val surahs = JSONArray(raw)
            var ayahCount = 0
            var valid = surahs.length() == 114
            for (i in 0 until surahs.length()) {
                val s = surahs.optJSONObject(i) ?: run { valid = false; continue }
                val name = s.optString("name")
                val ayahs = s.optJSONArray("ayahs")
                if (name.isBlank() || ayahs == null || ayahs.length() == 0) valid = false
                if (ayahs != null) {
                    ayahCount += ayahs.length()
                    for (j in 0 until ayahs.length()) {
                        if (ayahs.optString(j).isBlank()) valid = false
                    }
                }
                val row = TextView(this).apply {
                    text = "${i + 1}. $name"
                    textSize = 19f
                    setTextColor(green)
                    setPadding(12, 12, 12, 12)
                    setBackgroundColor(if (i % 2 == 0) Color.WHITE else Color.rgb(242, 238, 224))
                }
                list.addView(row)
            }
            if (valid && ayahCount == 6236) {
                status.text = "تم فحص البنية: 114 سورة و6236 آية. يلزم أيضًا التحقق من مطابقة النص للمصدر الموثوق."
                status.setTextColor(green)
            } else {
                status.text = "نسخة تجريبية غير مكتملة: لم يتم إدراج نص القرآن الكامل بعد. لا تستخدمها كمصحف."
                status.setTextColor(Color.rgb(150, 45, 35))
            }
        } catch (_: Exception) {
            status.text = "ملف القرآن غير جاهز. أضف البيانات القرآنية الموثوقة إلى app/src/main/assets/quran.json قبل النشر."
            status.setTextColor(Color.rgb(150, 45, 35))
        }
        val scroll = ScrollView(this)
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)
    }
}
