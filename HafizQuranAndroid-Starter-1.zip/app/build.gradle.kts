plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "org.example.hafizquran"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.example.hafizquran"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
